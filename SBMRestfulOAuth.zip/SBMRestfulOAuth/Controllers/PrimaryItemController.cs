﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Text.Json;
using Newtonsoft.Json.Linq;
using System.Dynamic;
using System.Xml.Linq;
using SBMRestful;
using System.Text;
using System;
using System.Net.Http;
using System.Threading.Tasks;
//using aewebservices71;
using System.Net;
using System.Xml;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Duende.IdentityServer.Models;

namespace SBMRestful.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PrimaryItemController : ControllerBase
    {
        private readonly string configFilePath = Path.Combine(Directory.GetCurrentDirectory(), "ConfigFields.xml");
        private readonly string authFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Auth.xml");
        private readonly string tokensFilePath = Path.Combine(Directory.GetCurrentDirectory(), "Tokens.xml");

        // In-memory storage for PrimaryItem objects
        private static List<PrimaryItem> primaryItems = new List<PrimaryItem>();

        private readonly IHttpClientFactory _httpClientFactory;

        // Inject IHttpClientFactory instead of HttpClient directly
        public PrimaryItemController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        [HttpGet("bearer")]
        [Authorize(AuthenticationSchemes = "Bearer")]
        public IActionResult GetDataBearer()
        {
            return Ok("This is data protected by Bearer scheme.");
        }

        [HttpGet("oauth2")]
        [Authorize(AuthenticationSchemes = "oauth2")]
        public IActionResult GetDataOAuth2()
        {
            return Ok("This is data protected by OAuth2 scheme.");
        }

        [HttpPost("token")]
        public IActionResult GetToken([FromForm] string client_id, [FromForm] string client_secret, [FromForm] string username, [FromForm] string password)
        {
            // Load XML config
            var configXml = XDocument.Load("IdentityConfig.xml");

            // Read security key from XML
            var securityKey = configXml.Descendants("Security").FirstOrDefault()?.Element("JwtSecretKey")?.Value;
            if (string.IsNullOrEmpty(securityKey))
            {
                return StatusCode(500, new { @return = new { message = "JWT Secret Key is missing in config." }});
            }

            // Validate Client ID & Secret
            var client = configXml.Descendants("Client").FirstOrDefault();
            if (client == null || client.Element("ClientId")?.Value != client_id || client.Element("ClientSecret")?.Value != client_secret)
            {
                return Unauthorized(new { @return = new { message = "Invalid Client ID or Secret." } });
            }

            // Handle Client Credentials Flow
            if (string.IsNullOrEmpty(username) && string.IsNullOrEmpty(password))
            {
                return Ok(new { token = GenerateJwtToken(client_id, securityKey) });
            }

            // Handle Password Grant Flow
            var user = configXml.Descendants("User").FirstOrDefault(u => u.Element("Username")?.Value == username && u.Element("Password")?.Value == password);
            if (user == null)
            {
                return Unauthorized(new { @return = new { message = "Invalid username or password." } });
            }

            return Ok(new { token = GenerateJwtToken(username, securityKey) });
        }

        private string GenerateJwtToken(string subject, string securityKey)
        {
            if (securityKey.Length < 16)
            {
                throw new ArgumentException("Security key must be at least 16 bytes (128 bits).");
            }

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(securityKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                claims: new[] { new Claim(ClaimTypes.Name, subject) },
                expires: DateTime.UtcNow.AddMinutes(30),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private bool IsValidToken(string token)
        {
            try
            {
                if (!System.IO.File.Exists(tokensFilePath))
                {
                    Console.WriteLine("Tokens.xml file not found!");
                    return false;
                }

                XDocument xmlDoc = XDocument.Load(tokensFilePath);
                var validTokens = xmlDoc.Descendants("Token").Select(x => x.Value).ToList();

                return validTokens.Contains(token); // Check if token is in XML
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading Tokens.xml: {ex.Message}");
                return false;
            }
        }

        // GET: api/GetVersion
        [HttpGet("GetVersion")]
        public async Task<IActionResult> GetVersion()
        {
            try
            {
                var authHeader = Request.Headers["Authorization"].ToString();

                if (string.IsNullOrEmpty(authHeader) || !authHeader.StartsWith("Bearer "))
                {
                    return Unauthorized("No token provided or incorrect format.");
                }

                var token = authHeader.Substring("Bearer ".Length);

                // Validate the token
                if (!IsValidToken(token))
                {
                    return Unauthorized("Invalid or expired token.");
                }

                PrimaryItem request = new PrimaryItem();
                request.Fields.Add("itemID", "1049:1");

                // Step 1: Generate the combined XML using BuildCreatePrimaryItem
                //var combinedXml = BuildCreatePrimaryItem(request.Fields);
                var xmlStringBuilder = new StringBuilder();
                var combinedXml = xmlStringBuilder.AppendLine($"  <urn:GetVersion/>").ToString();
                //var combinedXml = BuildGetItem(request.Fields);

                //var combinedXml = xmlStringBuilder.AppendLine($"  <urn:GetItem><urn:auth><urn:userId>nguyt38</urn:userId><urn:password>Tcrt$0927</urn:password></urn:auth><urn:itemID>1049:318346</urn:itemID></urn:GetItem>").ToString();


                // Step 2: Read the SOAP URL from the Auth.xml
                var soapUrl = GetSoapUrlFromAuth();

                // Step 3: Call the SOAP service with the generated XML
                var soapResponse = await CallPostSoapService(soapUrl, combinedXml);

                // Return the response from the SOAP service
                return Content(soapResponse, "application/xml");
            }
            catch (System.Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        // GET: api/PrimaryItem
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                // Read the dynamic fields from XML config
                var fields = ReadConfigFields();

                // Return the list of fields (you can expand this logic as per your needs)
                //return Ok(new { fields });
                return Ok(primaryItems);

            }
            catch (System.Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // POST: api/PrimaryItem
        [HttpPost]
        public IActionResult Post([FromBody] PrimaryItem primaryItem)
        {
            try
            {
                // Validate the input model
                if (primaryItem == null || primaryItem.Fields == null || primaryItem.Fields.Count == 0)
                {
                    return BadRequest("Invalid data.");
                }

                // Read the list of valid field names from the XML file
                var validFields = ReadConfigFields();

                // Validate each field in the POST request
                foreach (var field in primaryItem.Fields.Keys)
                {
                    if (!validFields.Contains(field))
                    {
                        return BadRequest($"Invalid field name: {field}");
                    }
                }

                // Save the item to the in-memory storage
                primaryItems.Add(primaryItem);

                // Here you can save or process the primaryItem as per your needs
                // For now, we are just returning the received data
                return Ok(new { Message = "PrimaryItem successfully received.", Data = primaryItem });
            }
            catch (System.Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // POST: api/PrimaryItem/BuildCreatePrimaryItem
        [HttpPost("BuildCreatePrimaryItem")]
        public IActionResult GetBuildCreatePrimaryItem([FromBody] PrimaryItem request)
        {
            try
            {
                // Validate the request
                if (request?.Fields == null || request.Fields.Count == 0)
                {
                    return BadRequest("Invalid data: Fields are required.");
                }

                // Read the list of valid field names from the ConfigFields.xml
                var validFields = ReadConfigFields();

                // Validate that all fields in the request are in the valid fields list
                foreach (var field in request.Fields.Keys)
                {
                    if (!validFields.Contains(field))
                    {
                        return BadRequest($"Invalid field name: {field}");
                    }
                }

                // Build the extended field list XML with the values from the request
                var extendedFieldListXml = BuildCreatePrimaryItem(request.Fields); // BuildExtendedFieldListXml(request.Fields);

                // Return the XML as plain text
                return Content(extendedFieldListXml, "application/xml");
            }
            catch (System.Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // POST: api/PrimaryItem/create
        [HttpPost("create")]
        public async Task<IActionResult> PostCreatePrimaryItem([FromBody] PrimaryItem request)
        {
            try
            {
                var authHeader = Request.Headers["Authorization"].ToString();

                if (string.IsNullOrEmpty(authHeader) || !authHeader.StartsWith("Bearer "))
                {
                    //return Unauthorized("No token provided or incorrect format.");
                    return Unauthorized(new { @return = new { message = "No token provided or incorrect format." } });
                }

                var token = authHeader.Substring("Bearer ".Length);

                // Validate the token
                if (!IsValidToken(token))
                {
                    //return Unauthorized("Invalid or expired token.");
                    return Unauthorized(new { @return = new { message = "Invalid or expired token." } });
                }


                if (request?.Fields == null || request.Fields.Count == 0)
                {
                    return BadRequest(new { @return = new { message = "Invalid data: Fields are required." } });
                    //return BadRequest("Invalid data: Fields are required.");
                }
                // Read the list of valid field names from the ConfigFields.xml
                var validFields = ReadConfigFields();

                // Validate that all fields in the request are in the valid fields list
                foreach (var field in request.Fields.Keys)
                {
                    if (!validFields.Contains(field))
                    {
                        return BadRequest(new { @return = new { message = $"Invalid field name: {field}" } });

                        //return BadRequest($"Invalid field name: {field}");
                    }
                }

                // Step 1: Generate the combined XML using BuildCreatePrimaryItem
                var combinedXml = BuildCreatePrimaryItem(request.Fields);

                // Step 2: Read the SOAP URL from the Auth.xml
                var soapUrl = GetSoapUrlFromAuth();

                // Step 3: Call the SOAP service with the generated XML
                var soapResponse = await CallPostSoapService(soapUrl, combinedXml);

                foreach (var field in request.Fields)
                {
                    var sbmname = GetSBMNameConfigFields(field.Key);
                    soapResponse = soapResponse.Replace($"'{sbmname}'", $"'{field.Key}'");
                }
                return Ok(new { @return = new { message = soapResponse } });
                    // Return the response from the SOAP service
                    //return Content(soapResponse, "application/xml");
            }
            catch (System.Exception ex)
            {
                return StatusCode(500,new { @return = new { message = $"Internal server error: {ex.Message}" } });

                //return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // POST: api/PrimaryItem/create
        [Authorize(AuthenticationSchemes = "oauth2")]
        [HttpPost("oauth/create")]
        //[Authorize(AuthenticationSchemes = "oauth2")]
        //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> PostCreatePrimaryItemOauth([FromBody] PrimaryItem request)
        {
            try
            {
                /*var authHeader = Request.Headers["Authorization"].ToString();

                if (string.IsNullOrEmpty(authHeader) || !authHeader.StartsWith("Bearer "))
                {
                    //return Unauthorized("No token provided or incorrect format.");
                    return Unauthorized(new { @return = new { message = "No token provided or incorrect format." } });
                }

                var token = authHeader.Substring("Bearer ".Length);

                // Validate the token
                if (!IsValidToken(token))
                {
                    //return Unauthorized("Invalid or expired token.");
                    return Unauthorized(new { @return = new { message = "Invalid or expired token." } });
                }*/


                if (request?.Fields == null || request.Fields.Count == 0)
                {
                    return BadRequest(new { @return = new { message = "Invalid data: Fields are required." } });
                    //return BadRequest("Invalid data: Fields are required.");
                }
                // Read the list of valid field names from the ConfigFields.xml
                var validFields = ReadConfigFields();

                // Validate that all fields in the request are in the valid fields list
                foreach (var field in request.Fields.Keys)
                {
                    if (!validFields.Contains(field))
                    {
                        return BadRequest(new { @return = new { message = $"Invalid field name: {field}" } });

                        //return BadRequest($"Invalid field name: {field}");
                    }
                }

                // Step 1: Generate the combined XML using BuildCreatePrimaryItem
                var combinedXml = BuildCreatePrimaryItem(request.Fields);

                // Step 2: Read the SOAP URL from the Auth.xml
                var soapUrl = GetSoapUrlFromAuth();

                // Step 3: Call the SOAP service with the generated XML
                var soapResponse = await CallPostSoapService(soapUrl, combinedXml);

                foreach (var field in request.Fields)
                {
                    var sbmname = GetSBMNameConfigFields(field.Key);
                    soapResponse = soapResponse.Replace($"'{sbmname}'", $"'{field.Key}'");
                }
                return Ok(new { @return = new { message = soapResponse } });
                // Return the response from the SOAP service
                //return Content(soapResponse, "application/xml");
            }
            catch (System.Exception ex)
            {
                return StatusCode(500, new { @return = new { message = $"Internal server error: {ex.Message}" } });

                //return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // POST: api/PrimaryItem/get
        [HttpPost("get")]
        public async Task<IActionResult> PostGetItem([FromBody] PrimaryItem request)
        {
            try
            {
                if (request?.Fields == null || request.Fields.Count == 0)
                {
                    return BadRequest("Invalid data: Fields are required.");
                }
                // Read the list of valid field names from the ConfigFields.xml
                //var validFields = ReadConfigFields();

                // Validate that all fields in the request are in the valid fields list
                //foreach (var field in request.Fields.Keys)
                //{
                //    if (!validFields.Contains(field))
                //    {
                //        return BadRequest($"Invalid field name: {field}");
                //    }
                //}

                // Step 1: Generate the combined XML using BuildCreatePrimaryItem
                var combinedXml = BuildGetItem(request.Fields);

                // Step 2: Read the SOAP URL from the Auth.xml
                var soapUrl = GetSoapUrlFromAuth();

                // Step 3: Call the SOAP service with the generated XML
                var soapResponse = await CallPostSoapService(soapUrl, combinedXml);

                //var soapResponse = combinedXml;
                // Return the response from the SOAP service
                return Content(soapResponse, "application/xml");
                //return Content(combinedXml, "application/xml");
            }
            catch (System.Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        private string GetSoapUrlFromAuth()
        {
            if (!System.IO.File.Exists(authFilePath))
                throw new FileNotFoundException("Auth.xml not found.");

            var xmlDoc = XDocument.Load(authFilePath);
            var soapUrl = xmlDoc.Descendants("SoapUrl").FirstOrDefault()?.Value;

            if (soapUrl == null)
            {
                throw new InvalidDataException("SoapUrl not found in Auth.xml.");
            }

            return soapUrl;
        }

        // Helper method to call the SOAP service
        private async Task<string> CallPostSoapService(string soapUrl, string requestXml)
        {
            // Prepare the SOAP envelope with the request XML
            var soapEnvelope = CreateSoapEnvelope(requestXml);

            // Create the HTTP client using IHttpClientFactory
            var client = _httpClientFactory.CreateClient();
            //client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", "Base64EncodedCredentials");
            // Create the HTTP content for the SOAP request


            var content = new StringContent(soapEnvelope, Encoding.UTF8, "text/xml");

            // Set the necessary headers
            content.Headers.Add("SOAPAction", "\"\""); // The SOAPAction header may vary depending on your service.
            //content.Headers.Add("SOAPAction", "GET");
            // Set the headers based on the raw request
            //content.Headers.Add("Accept-Encoding", "gzip,deflate");
            //content.Headers.Add("Content-Type", "text/xml;charset=UTF-8");
            //content.Headers.Add("SOAPAction", ""); // Empty SOAPAction
            //content.Headers.Add("User-Agent", "Apache-HttpClient/4.1.1 (java 1.5)");

            // Send the POST request to the SOAP service
            var response = await client.PostAsync(soapUrl, content);
            //var response1 = await aewebservices71.GetVersion;
            string responseContent = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
            {
                if (response.StatusCode == HttpStatusCode.InternalServerError) // 500 Error
                {
                    string faultMessage = ExtractSoapFault(responseContent);
                    //Console.WriteLine($"SOAP Fault: {faultMessage}");
                    return faultMessage;
                }
                throw new HttpRequestException($"SOAP request failed with status code {response.StatusCode}");
            }

            // Read and return the response body
            //return await response.Content.ReadAsStringAsync();
            return ExtractSoapReturn(responseContent);
        }

        private string ExtractSoapFault(string soapResponse)
        {
            try
            {
                XDocument soapXml = XDocument.Parse(soapResponse);
                XNamespace soapNs = "http://schemas.xmlsoap.org/soap/envelope/";

                var fault = soapXml.Descendants(soapNs + "Fault").FirstOrDefault();
                if (fault != null)
                {
                    string faultCode = fault.Element("faultcode")?.Value;
                    string faultString = fault.Element("faultstring")?.Value;
                    string detailString = fault.Element("detail")?.Value;

                    return $"Fault Message: {faultString}".Replace("\r", "");//.Replace("\n", "");
                    //return $"Fault Code: {faultCode} \nFault Message: {faultString}";
                    //return $"Fault Code: {faultCode} \nFault Message: {faultString} \nDetail Message: {detailString}";
                }
            }
            catch (Exception ex)
            {
                return $"Error parsing SOAP Fault: {ex.Message}";
            }

            return "Unknown SOAP Fault format.";
        }

        private string ExtractSoapReturn(string soapResponse)
        {
            try
            {
                XDocument soapXml = XDocument.Parse(soapResponse);
                XNamespace soapNs = "http://schemas.xmlsoap.org/soap/envelope/";

                //var returnString = soapXml.Descendants(soapNs + "ae:return").FirstOrDefault();
                // Extract ae:return
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(soapResponse);
                // Create Namespace Manager
                XmlNamespaceManager nsManager = new XmlNamespaceManager(xmlDoc.NameTable);
                nsManager.AddNamespace("ae", "urn:aewebservices71");  // Ensure this matches the XML namespace

                // Extract ae:return value
                XmlNode node = xmlDoc.SelectSingleNode("//ae:return", nsManager);
                //XmlNode node = xmlDoc.SelectSingleNode("//ae:return");

                if (node != null)
                {
                    // Extracting values using XPath with namespace
                    string itemName = xmlDoc.SelectSingleNode("//ae:genericItem/ae:itemName", nsManager)?.InnerText;
                    
                    // Extract COMMENTS field
                    XmlNode commentsNode = xmlDoc.SelectSingleNode("//ae:extendedFieldList[ae:name='COMMENTS']/ae:value", nsManager);
                    string commentsDisplayValue = commentsNode?.SelectSingleNode("ae:displayValue", nsManager)?.InnerText;
                    string commentsInternalValue = commentsNode?.SelectSingleNode("ae:internalValue", nsManager)?.InnerText;

                    if (itemName != null)
                    {
                        string strreturn = $"Your interface request has been successfully submitted to Labcorp. The Item ＃ is {itemName}"; //scomment.Replace("#", "＃")
                        if (commentsDisplayValue != null && commentsDisplayValue != "")
                        {
                            strreturn = strreturn + "\n'Ext Submit Validation Results’: " + commentsDisplayValue;
                        }
                        return strreturn.Replace("\r", "");
                    }
                    else
                       return node.InnerXml;
                    //string faultCode = fault.Element("faultcode")?.Value;
                    // faultString = fault.Element("faultstring")?.Value;
                    //string detailString = fault.Element("detail")?.Value;
                    //return $"Fault Code: {faultCode} \nFault Message: {faultString} \nDetail Message: {detailString}";
                    //return returnString.ToString();
                }
            }
            catch (Exception ex)
            {
                return $"Error parsing SOAP Fault: {ex.Message}";
            }

            return "Unknown SOAP Fault format.";
        }

        private async Task<string> CallSoapService(string soapUrl, string requestXml)
        {
            // Prepare the SOAP envelope with the request XML
            var soapEnvelope = CreateSoapEnvelope(requestXml);

            // Create the HTTP client using IHttpClientFactory
            var client = _httpClientFactory.CreateClient();
            //client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", "Base64EncodedCredentials");
            // Create the HTTP content for the SOAP request


            var content = new StringContent(soapEnvelope, Encoding.UTF8, "text/xml");



            // Set the necessary headers
            content.Headers.Add("SOAPAction", "\"\""); // The SOAPAction header may vary depending on your service.
                                                       //content.Headers.Add("SOAPAction", "GET");
                                                       // Set the headers based on the raw request
                                                       //content.Headers.Add("Accept-Encoding", "gzip,deflate");
                                                       //content.Headers.Add("Content-Type", "text/xml;charset=UTF-8");
                                                       //content.Headers.Add("SOAPAction", ""); // Empty SOAPAction
                                                       //content.Headers.Add("User-Agent", "Apache-HttpClient/4.1.1 (java 1.5)");

            // Send the POST request to the SOAP service
            var response = await client.PostAsync(soapUrl, content);

            if (!response.IsSuccessStatusCode)
            {
                throw new HttpRequestException($"SOAP request failed with status code {response.StatusCode}");
            }

            // Read and return the response body
            return await response.Content.ReadAsStringAsync();
        }

        // Helper method to create SOAP envelope
        private string CreateSoapEnvelope(string requestXml)
        {
            // Wrap the requestXml in a SOAP envelope
            var soapEnvelope = new StringBuilder();
            //soapEnvelope.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            soapEnvelope.AppendLine("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:aewebservices71\">");
            soapEnvelope.AppendLine($"  <soapenv:Header/>");
            soapEnvelope.AppendLine($"  <soapenv:Body>");

            soapEnvelope.AppendLine(requestXml);

            soapEnvelope.AppendLine($"  </soapenv:Body>");
            soapEnvelope.AppendLine("</soapenv:Envelope>");

            return soapEnvelope.ToString();
        }


        private string BuildCreatePrimaryItem(Dictionary<string, string> fields)
        {
            var xmlStringBuilder = new StringBuilder();

            //xmlStringBuilder.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            //xmlStringBuilder.AppendLine("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:aewebservices71\">");
            //xmlStringBuilder.AppendLine($"  <soapenv:Header/>");
            //xmlStringBuilder.AppendLine($"  <soapenv:Body>");
            xmlStringBuilder.AppendLine($"  <urn:CreatePrimaryItem>");

            var AuthXml = BuildAuth();
            xmlStringBuilder.AppendLine(AuthXml);

            var xmlDoc = XDocument.Load(authFilePath);
            var projectID = xmlDoc.Descendants("projectID").FirstOrDefault()?.Value;

            if (projectID == null)
            {
                throw new InvalidDataException("Missing required projectID in Auth.xml.");
            }

            xmlStringBuilder.AppendLine($"<urn:projectID>{projectID}</urn:projectID>");

            var submitTransID = xmlDoc.Descendants("submitTransID").FirstOrDefault()?.Value;

            if (submitTransID == null)
            {
                throw new InvalidDataException("Missing required submitTransID in Auth.xml.");
            }

            xmlStringBuilder.AppendLine($"<urn:submitTransID>{submitTransID}</urn:submitTransID>");

            xmlStringBuilder.AppendLine($"  <urn:item>");

            string scomments = ValidateFields(fields);
            if (scomments != "")
            {
                throw new InvalidDataException(scomments);
            }
            var extendedFieldListXml = BuildExtendedFieldListXml(fields);
            xmlStringBuilder.AppendLine(extendedFieldListXml);

            xmlStringBuilder.AppendLine($"  </urn:item>");

            xmlStringBuilder.AppendLine($"  </urn:CreatePrimaryItem>");
            //xmlStringBuilder.AppendLine($"  </soapenv:Body>");
            //xmlStringBuilder.AppendLine("</soapenv:Envelope>");

            return xmlStringBuilder.ToString().Replace("\r", "").Replace("\n", "");

        }

        private string BuildGetItem(Dictionary<string, string> fields)
        {
            var xmlStringBuilder = new StringBuilder();

            xmlStringBuilder.AppendLine($"  <urn:GetItem>");

            var AuthXml = BuildAuth();
            xmlStringBuilder.AppendLine(AuthXml);

            var itemID = "";

            foreach (var field in fields)
            {
                if (field.Key == "itemID") itemID = field.Value;
            }

            if (itemID == null || itemID == "")
            {
                throw new InvalidDataException("Missing required itemID");
            }

            xmlStringBuilder.AppendLine($"<urn:itemID>{itemID}</urn:itemID>");

            xmlStringBuilder.AppendLine($"  </urn:GetItem>");

            return xmlStringBuilder.ToString().Replace("\r", "").Replace("\n", "");

        }

        // Helper method to read values from Auth.xml and build the XML structure
        private string BuildAuth()
        {
            if (!System.IO.File.Exists(authFilePath))
                throw new FileNotFoundException("Auth.xml not found.");

            // Load the Auth.xml file
            var xmlDoc = XDocument.Load(authFilePath);

            // Extract the values from the XML file
            var userId = xmlDoc.Descendants("userId").FirstOrDefault()?.Value;
            var password = xmlDoc.Descendants("password").FirstOrDefault()?.Value;
            //var projectID = xmlDoc.Descendants("projectID").FirstOrDefault()?.Value;

            // If any of the values are missing, throw an exception
            if (userId == null || password == null)
            {
                throw new InvalidDataException("Missing required values in Auth.xml.");
            }

            // Build the XML string with the required structure
            var xmlStringBuilder = new StringBuilder();
            //xmlStringBuilder.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            xmlStringBuilder.AppendLine("<urn:auth>");
            xmlStringBuilder.AppendLine($"  <urn:userId>{userId}</urn:userId>");
            xmlStringBuilder.AppendLine($"  <urn:password>{password}</urn:password>");
            xmlStringBuilder.AppendLine("</urn:auth>");
            //xmlStringBuilder.AppendLine($"<urn:projectID>{projectID}</urn:projectID>");

            return xmlStringBuilder.ToString();
        }

        // Helper method to build the XML structure with the field values
        private string BuildExtendedFieldListXml(Dictionary<string, string> fields)
        {
            var xmlStringBuilder = new StringBuilder();

            //xmlStringBuilder.AppendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
            //xmlStringBuilder.AppendLine("<urn:extendedFieldListList>");

            foreach (var field in fields)
            {
                xmlStringBuilder.AppendLine("<urn:extendedFieldList>");
                xmlStringBuilder.AppendLine($"  <urn:name>{GetNameConfigFields(field.Key)}</urn:name>");
                xmlStringBuilder.AppendLine("  <urn:value>");
                xmlStringBuilder.AppendLine($"    <urn:displayValue>{field.Value}</urn:displayValue>");
                xmlStringBuilder.AppendLine("  </urn:value>");
                xmlStringBuilder.AppendLine("</urn:extendedFieldList>");
            }

            //xmlStringBuilder.AppendLine("</urn:extendedFieldListList>");
            return xmlStringBuilder.ToString().Replace("\r", "").Replace("\n", "");
        }

        private string ValidateFields(Dictionary<string, string> fields)
        {
            string maxlength = "";
            bool isvalid = true;
            string scomment = "";
            foreach (var field in fields)
            {
                maxlength = GetMaxLengthConfigFields(field.Key);
                if (field.Value.Length > int.Parse(maxlength))
                {
                    isvalid = false;
                    scomment = scomment + field.Key + " is greater than " + maxlength + " characters - " + field.Value + "\n\n";
                }
            }
            if (isvalid) return "";
            else return scomment.Replace("#", "＃").Replace(":", "：");
        }

        // Helper method to read fields from the ConfigFields.xml file
        private List<string> ReadConfigFields()
        {
            if (!System.IO.File.Exists(configFilePath))
                throw new FileNotFoundException("ConfigFields.xml not found.");

            var xmlDoc = XDocument.Load(configFilePath);
            var fields = xmlDoc.Descendants("Field")
                               .Select(x => x.Attribute("apiname")?.Value)
                               .Where(name => !string.IsNullOrEmpty(name))
                               .ToList();

            return fields;
        }
        private string GetNameConfigFields(string apiname)
        {
            if (!System.IO.File.Exists(configFilePath))
                throw new FileNotFoundException("ConfigFields.xml not found.");

            var xmlDoc = XDocument.Load(configFilePath);
            var field = xmlDoc.Descendants("Field")
                       .FirstOrDefault(f => (string)f.Attribute("apiname") == apiname);

            return field != null ? (string)field.Attribute("name") : null;
        }
        private string GetMaxLengthConfigFields(string apiname)
        {
            if (!System.IO.File.Exists(configFilePath))
                throw new FileNotFoundException("ConfigFields.xml not found.");

            var xmlDoc = XDocument.Load(configFilePath);
            var field = xmlDoc.Descendants("Field")
                       .FirstOrDefault(f => (string)f.Attribute("apiname") == apiname);

            return field != null ? (string)field.Attribute("maxlength") : null;
        }

        private string GetSBMNameConfigFields(string apiname)
        {
            if (!System.IO.File.Exists(configFilePath))
                throw new FileNotFoundException("ConfigFields.xml not found.");

            var xmlDoc = XDocument.Load(configFilePath);
            var field = xmlDoc.Descendants("Field")
                       .FirstOrDefault(f => (string)f.Attribute("apiname") == apiname);

            return field != null ? (string)field.Attribute("sbmname") : null;
        }
    }





    public class PrimaryItem
    {
        public Dictionary<string, string> Fields { get; set; } = new Dictionary<string, string>();
    }

}




