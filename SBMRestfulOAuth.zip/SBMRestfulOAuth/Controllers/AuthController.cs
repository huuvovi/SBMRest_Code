﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Xml.Serialization;

namespace SBMRestful.Controllers
{
    [ApiController]
    [Route("api/auth")]
    public class AuthController : ControllerBase
    {
        private readonly IdentityConfig _config;

        public AuthController()
        {
            _config = LoadXml<IdentityConfig>("IdentityConfig.xml");
        }

        [HttpPost("token")]
        public IActionResult GetToken([FromForm] string client_id, [FromForm] string client_secret)
        {
            var client = _config.Clients.FirstOrDefault(c =>
                c.ClientId == client_id && c.ClientSecret == client_secret &&
                c.GrantType == "client_credentials");

            if (client == null)
                return Unauthorized("Invalid client credentials");

            var key = Encoding.UTF8.GetBytes(_config.Security.JwtSecretKey);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                new Claim("client_id", client.ClientId)
            }),
                Expires = DateTime.UtcNow.AddHours(1),
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature)
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            var tokenString = tokenHandler.WriteToken(token);

            return Ok(new
            {
                access_token = tokenString,
                token_type = "Bearer",
                expires_in = 3600
            });
        }

        private static T LoadXml<T>(string filePath)
        {
            var serializer = new XmlSerializer(typeof(T));
            using var reader = new StreamReader(filePath);
            return (T)serializer.Deserialize(reader);
        }
    }
}
