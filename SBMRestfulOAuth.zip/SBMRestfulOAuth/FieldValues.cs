﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;

namespace SBMRestful
{   

    public class FieldValues
    {
        // This will hold the dynamic fields (name and type)
        public List<Field> Fields { get; set; }

        // Constructor to initialize the Fields list
        public FieldValues()
        {
            Fields = new List<Field>();
        }

        // Load fields from the XML file
        public void LoadFieldsFromXml(string configFilePath)
        {
            // Load the XML document
            var doc = XDocument.Load(configFilePath);

            // Loop through the XML elements and add them to the Fields list
            foreach (var element in doc.Descendants("Field"))
            {
                var name = element.Element("Name")?.Value;
                var type = element.Element("Type")?.Value;

                // Add a field if both name and type are present
                if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(type))
                {
                    Fields.Add(new Field
                    {
                        Name = name,
                        Type = type
                    });
                }
            }
        }
    }

    public class Field
    {
        public string Name { get; set; }
        public string Type { get; set; }
    }

}
