﻿namespace SBMRestful
{
    public class IdentityConfig
    {
        public List<Client> Clients { get; set; }
        public List<User> Users { get; set; }
        public Security Security { get; set; }
    }

    public class Client
    {
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string GrantType { get; set; }
        public string TokenEndpoint { get; set; }
    }

    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    public class Security
    {
        public string JwtSecretKey { get; set; }
    }
}
