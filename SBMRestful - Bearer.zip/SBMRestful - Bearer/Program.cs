using Microsoft.OpenApi.Models;
using SBMRestful;
//using Microsoft.AspNetCore.Authentication.AuthenticationToken;
var builder = WebApplication.CreateBuilder(args);

// Register IHttpClientFactory to enable HttpClient injection
builder.Services.AddHttpClient();

// Register the config service
// Register ConfigService as a singleton (or scoped depending on needs)
//builder.Services.AddSingleton<ConfigService>();

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen();

builder.Services.AddSwaggerGen(options =>
{
    // Add OAuth2 Security Definition (Bearer Token)
    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Type = SecuritySchemeType.Http,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Name = "Authorization",
        Description = "Enter 'Bearer {your-token}'"
    });

    // Add Security Requirement
    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
            },
            new string[] { }
        }
    });
});

var app = builder.Build();

// Configure Kestrel to listen on any IP address (0.0.0.0)
//app.Urls.Add("http://localhost:81"); // You can replace 5000 with any port number you prefer.


// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
    app.UseSwagger();
    app.UseSwaggerUI();
//}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
