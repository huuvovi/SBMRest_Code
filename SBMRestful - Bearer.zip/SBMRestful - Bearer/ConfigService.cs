﻿
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using SBMRestful; // Namespace for ConfigService
using SBMRestful.Controllers; // Namespace for PrimaryItemController


namespace SBMRestful
{
    public class ConfigService
    {
        private readonly string configFilePath = "Configfields.xml";
        private readonly string configSslFilePath = "Config.xml";

        public List<KeyValuePair<string, Type>> GetFields()
        {
            var fields = new List<KeyValuePair<string, Type>>();
            try
            {
                var doc = XDocument.Load(configFilePath);
                var fieldElements = doc.Descendants("Field");

                foreach (var field in fieldElements)
                {
                    var name = field.Element("Name")?.Value;
                    var type = field.Element("Type")?.Value;

                    if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(type))
                        continue;

                    Type fieldType = Type.GetType($"System.{type}", true, true);

                    fields.Add(new KeyValuePair<string, Type>(name, fieldType));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading config: {ex.Message}");
            }

            return fields;
        }

        public int GetSslPort()
        {
            try
            {
                var xmlDoc = XDocument.Load(configSslFilePath);
                var sslPortElement = xmlDoc.Descendants("SslPort").FirstOrDefault();
                if (sslPortElement != null)
                {
                    return int.Parse(sslPortElement.Value);
                }
                else
                {
                    throw new Exception("SslPort not found in the configuration.");
                }
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Error reading SSL port from XML file", ex);
            }
        }
    }
}
